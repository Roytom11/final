export class Version {
  constructor(
    public id: string,
    public content: any,
    public timestamp: Date = new Date()
  ) {}
}