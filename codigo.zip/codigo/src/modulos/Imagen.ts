import { Documento } from "./Documento";

export interface ImageData {
  format: string;
  width: number;
  height: number;
}

export class Imagen extends Documento {
      protected validate(): void {
    const data = this.content as ImageData;
    const formatoValido = ["png", "jpg", "bmp"];

    if (!formatoValido.includes(data.format)) {
      throw new Error("Formato de imagen no valido (use png, jpg o bmp).");
    }
    if (data.width < 100 || data.height < 100) {
      throw new Error("Las dimensiones minimas son 100x100 píxeles.");
    }
  }
}