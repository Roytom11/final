import { Documento } from "./Documento";

export class Texto extends Documento {
  protected validate(): void {
    if (typeof this.content !== "string" || this.content.trim() === "") {
      throw new Error("El campo texto no puede estar vacío.");
    }
  }
}