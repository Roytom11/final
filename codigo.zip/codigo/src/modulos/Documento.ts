import { Version } from "./Version";

export  abstract class Documento {
    
    protected versions: Version[] = [];
    private static versionCounter = 0;
    constructor(public name: string, protected content: any) {
         this.saveVersion();
    }

      public save(): void {
    this.validate();
    this.saveVersion();
    console.log(` el documento "${this.name}" se guardo correctamente`);
  }

   protected abstract validate(): void;

 protected saveVersion(): void {
    const versionId = ++Documento.versionCounter; 
    const version = new Version(versionId.toString(), JSON.parse(JSON.stringify(this.content)));
    this.versions.push(version);
  }

   public edit(newContent: any): void {
    this.content = newContent;
  }

   public delete(): void {
    console.log(` Documento "${this.name}" eliminado.`);
  }

  public restaurarVersiones(versionId: string): void {
    const version = this.versions.find(v => v.id === versionId);
    if (!version) throw new Error(" Version no encontrada");
    this.content = JSON.parse(JSON.stringify(version.content));
    console.log(` Documento restaurado a version ${versionId}`);
  }

  public historialVersiones(): void {
    const recent = this.versions.slice(-10);
    console.log(`Ultimas ${recent.length} versiones del documento "${this.name}":`);
    recent.forEach(v => console.log(`→ ID: ${v.id} (${v.timestamp.toLocaleString()})`));
  }

  public enecimaVersion(n: number): void {
    if (n <= 0 || n > this.versions.length) {
      console.log("Numero de version invalido.");
      return;
    }
    const v = this.versions[n - 1];
    console.log(` Version #${n}: ID=${v.id}, Fecha=${v.timestamp.toLocaleString()}`);
  }

   public getContent(): any {
    return this.content;
  }
}