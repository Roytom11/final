import { Texto } from "./src/modulos/Texto";
import { Imagen } from "./src/modulos/Imagen";
try {
    const doc1 = new Texto("Contrato", "Este es un contrato para Rodrigo Brzek");
    doc1.edit("Nueva version del contrato con modificaciones");
    doc1.save();
    const img1 = new Imagen("ImagenEmpresa", {
        format: "png",
        width: 200,
        height: 200
    });
    img1.save();
    img1.edit({ format: "jpg", width: 300, height: 300 });
    img1.save();
    doc1.historialVersiones();
    img1.historialVersiones();
    const versionToRestore = img1.versions[0].id;
    img1.restaurarVersiones(versionToRestore);
    doc1.enecimaVersion(1);
}
catch (error) {
    console.error(error.message);
}
